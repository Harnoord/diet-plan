
function login() {
    const username = document.getElementById('username').value;
    const password = document.getElementById('password').value;

    
    
    window.location.href = '/Users/harnoordhillon/Documents/untitled folder/Harnoor fitness club/diet-plan/dietplan.html';
    document.getElementById('login-section').style.display = 'none';
    document.getElementById('logout-section').style.display = 'block';
    document.getElementById('user-display').innerText = username;
}


function logout() {
 
    document.getElementById('login-section').style.display = 'block';
    document.getElementById('logout-section').style.display = 'none';
    document.getElementById('username').value = '';
    document.getElementById('password').value = '';
}
